ADMIN_THEME = "admin"
DEFAULT_THEME = "core"
