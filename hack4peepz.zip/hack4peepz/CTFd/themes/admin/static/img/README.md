Original Logo by [Laura Barbera](https://dribbble.com/lauragallisa)
Updated by [Kevin Chung](https://github.com/ColdHeat)
